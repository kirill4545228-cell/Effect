package dev.goldencelestial;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class GoldenCelestialEffect extends JavaPlugin implements TabExecutor {

    private final Set<CelestialAnimation> active = new HashSet<>();
    private DashFeather dashFeather;

    @Override
    public void onEnable() {
        dashFeather = new DashFeather(this);
        getServer().getPluginManager().registerEvents(dashFeather, this);
        if (getCommand("effect1") != null) {
            getCommand("effect1").setExecutor(this);
            getCommand("effect1").setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        for (CelestialAnimation animation : new ArrayList<>(active)) {
            animation.stop();
        }
        active.clear();
        if (dashFeather != null) {
            dashFeather.shutdown();
        }
        getServer().getScheduler().cancelTasks(this);
    }

    void onAnimationFinished(CelestialAnimation animation) {
        active.remove(animation);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Команда доступна только игрокам.");
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("feather")) {
            if (!player.hasPermission("goldencelestial.feather")) {
                player.sendMessage(Component.text("Нет прав.", NamedTextColor.RED));
                return true;
            }
            Map<Integer, ItemStack> left = player.getInventory().addItem(dashFeather.createFeather());
            for (ItemStack rest : left.values()) {
                player.getWorld().dropItem(player.getLocation(), rest);
            }
            player.sendMessage(Component.text("Вы получили золотое перо рывка.", NamedTextColor.GOLD));
            return true;
        }

        CelestialAnimation animation = new CelestialAnimation(this, player.getLocation());
        active.add(animation);
        animation.start();
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1 && sender.hasPermission("goldencelestial.feather")
                && "feather".startsWith(args[0].toLowerCase())) {
            return List.of("feather");
        }
        return List.of();
    }
}

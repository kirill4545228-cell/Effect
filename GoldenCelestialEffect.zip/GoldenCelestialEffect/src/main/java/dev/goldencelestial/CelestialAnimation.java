package dev.goldencelestial;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;

/**
 * Одна копия анимации = одна задача BukkitRunnable (1 раз в тик, главный поток).
 * Задача сама отменяется по окончании. Копии полностью независимы друг от друга.
 */
public final class CelestialAnimation extends BukkitRunnable {

    // ---- Тайминги (тики, 20 тиков = 1 секунда) ----
    private static final int TOTAL_TICKS = 290;      // ~14.5 c
    private static final int FLASH_TICK = 225;       // момент вспышки
    private static final int ASSEMBLE_TICKS = 120;   // сборка сферы
    private static final int CHARGE_START = 170;     // начало сжатия перед вспышкой

    // ---- Геометрия ----
    private static final double RADIUS = 5.0;
    private static final double CENTER_HEIGHT = 7.0;
    private static final int SPHERE_STRIDE = 5;      // каждая точка сферы рисуется раз в N тиков

    private static final double[] RING_R = {6.8, 8.4, 10.0, 11.6};
    private static final double[] RING_TILT = {0.35, 1.05, -0.70, 1.55};
    private static final double[] RING_SPIN = {0.070, -0.045, 0.030, -0.090};
    private static final double[] RING_PREC = {0.020, -0.015, 0.025, 0.012};
    private static final int[] RING_START = {15, 35, 55, 75};
    private static final int RING_POINTS = 96;

    private static final int COLUMNS = 18;
    private static final int MAX_BEAMS = 12;

    // ---- Частицы ----
    private static final Particle.DustOptions GOLD = new Particle.DustOptions(Color.fromRGB(255, 200, 30), 1.3f);
    private static final Particle.DustOptions GOLD_BRIGHT = new Particle.DustOptions(Color.fromRGB(255, 226, 90), 1.1f);
    private static final Particle.DustOptions WHITE_GOLD = new Particle.DustOptions(Color.fromRGB(255, 248, 215), 2.2f);
    private static final Particle.DustOptions CORE_GOLD = new Particle.DustOptions(Color.fromRGB(255, 190, 20), 2.4f);
    private static final BlockData GOLD_BLOCK = Material.GOLD_BLOCK.createBlockData();

    private static final class Beam {
        final double dx, dy, dz, length;
        final int born, life;

        Beam(double dx, double dy, double dz, double length, int born, int life) {
            this.dx = dx;
            this.dy = dy;
            this.dz = dz;
            this.length = length;
            this.born = born;
            this.life = life;
        }
    }

    private final GoldenCelestialEffect plugin;
    private final World world;
    private final double ox, oy, oz;   // точка на земле (где стоял игрок)
    private final double cx, cy, cz;   // центр сферы
    private final Random rnd = new Random();
    private final List<Beam> beams = new ArrayList<>();

    private int tick = 0;
    private int prevVisible = 0;
    private boolean finished = false;

    public CelestialAnimation(GoldenCelestialEffect plugin, Location origin) {
        this.plugin = plugin;
        this.world = origin.getWorld();
        this.ox = origin.getX();
        this.oy = origin.getY();
        this.oz = origin.getZ();
        this.cx = ox;
        this.cy = oy + CENTER_HEIGHT;
        this.cz = oz;
    }

    /** Запускает анимацию немедленно (без задержки), период — 1 тик. */
    public void start() {
        runTaskTimer(plugin, 0L, 1L);
    }

    public void stop() {
        finish();
    }

    private void finish() {
        if (finished) {
            return;
        }
        finished = true;
        try {
            cancel();
        } catch (IllegalStateException ignored) {
            // задача ещё не была запланирована
        }
        plugin.onAnimationFinished(this);
    }

    @Override
    public void run() {
        if (finished) {
            return;
        }
        if (tick >= TOTAL_TICKS || world.getPlayers().isEmpty()) {
            finish();
            return;
        }
        try {
            playSounds();
            if (tick < FLASH_TICK) {
                buildUp();
            } else {
                if (tick == FLASH_TICK) {
                    flash();
                }
                afterFlash(tick - FLASH_TICK);
            }
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.WARNING, "Ошибка анимации, эффект остановлен", ex);
            finish();
            return;
        }
        tick++;
    }

    // =====================================================================
    // Звук
    // =====================================================================

    private void playSounds() {
        Location c = new Location(world, cx, cy, cz);
        if (tick == 0) {
            world.playSound(c, Sound.BLOCK_BEACON_ACTIVATE, 4.0f, 1.2f);
        } else if (tick == 60) {
            world.playSound(c, Sound.BLOCK_BEACON_POWER_SELECT, 4.0f, 1.4f);
        } else if (tick == CHARGE_START) {
            world.playSound(c, Sound.ENTITY_PLAYER_LEVELUP, 4.0f, 0.5f);
        } else if (tick == FLASH_TICK) {
            world.playSound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 5.0f, 1.3f);
            world.playSound(c, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 5.0f, 0.7f);
            world.playSound(c, Sound.ITEM_TOTEM_USE, 4.0f, 1.0f);
        }
    }

    // =====================================================================
    // Фаза сборки / зарядки
    // =====================================================================

    private void buildUp() {
        double assemble = Math.min(1.0, tick / (double) ASSEMBLE_TICKS);
        double eased = assemble * assemble * (3.0 - 2.0 * assemble);
        double charge = tick < CHARGE_START ? 0.0 : (tick - CHARGE_START) / (double) (FLASH_TICK - CHARGE_START);
        double charge2 = charge * charge;
        double radius = RADIUS * (1.0 - 0.35 * charge2) + 0.12 * Math.sin(tick * 0.8) * charge;
        double coreScale = 0.5 + 0.6 * eased + 1.8 * charge2;

        drawCore(coreScale, charge);
        drawSphere(radius, eased);

        double ratio = radius / RADIUS;
        for (int i = 0; i < RING_R.length; i++) {
            if (tick >= RING_START[i]) {
                drawRing(i, RING_R[i] * ratio, Math.min(1.0, (tick - RING_START[i]) / 30.0));
            }
        }

        updateBeams();
        drawGround();
        drawAmbient(radius);
    }

    private void drawCore(double s, double charge) {
        burst(Particle.END_ROD, cx, cy, cz, (int) (14 + 26 * s), s * 0.30, s * 0.30, s * 0.30, 0.02);
        burst(Particle.GLOW, cx, cy, cz, (int) (6 + 8 * s), s * 0.5, s * 0.5, s * 0.5, 0.04);
        dust(WHITE_GOLD, cx, cy, cz, (int) (10 + 8 * s), s * 0.25, s * 0.25, s * 0.25);
        dust(CORE_GOLD, cx, cy, cz, (int) (14 + 10 * s), s * 0.55, s * 0.55, s * 0.55);
        if (tick % 8 == 0) {
            burst(Particle.FIREWORK, cx, cy, cz, 14, 0, 0, 0, 0.18 + 0.2 * charge);
        }
        if (charge > 0 && tick % 2 == 0) {
            burst(Particle.ELECTRIC_SPARK, cx, cy, cz, 10, 0, 0, 0, 0.5 + charge);
        }
    }

    private void drawSphere(double radius, double eased) {
        int visible = (int) (SphereData.COUNT * eased);
        double a = tick * 0.025;
        double c = Math.cos(a);
        double s = Math.sin(a);
        double[] X = SphereData.X;
        double[] Y = SphereData.Y;
        double[] Z = SphereData.Z;

        for (int k = tick % SPHERE_STRIDE; k < visible; k += SPHERE_STRIDE) {
            double x = X[k] * c - Z[k] * s;
            double z = X[k] * s + Z[k] * c;
            double y = Y[k];
            double px = cx + x * radius;
            double py = cy + y * radius;
            double pz = cz + z * radius;
            int m = (k / SPHERE_STRIDE) % 12;
            if (m == 0) {
                burst(Particle.END_ROD, px, py, pz, 1, 0, 0, 0, 0);
            } else if (m <= 4) {
                dust(GOLD_BRIGHT, px, py, pz, 1, 0, 0, 0);
            } else {
                dust(GOLD, px, py, pz, 1, 0, 0, 0);
            }
        }

        // новые точки «прилетают» снаружи к сфере
        for (int k = prevVisible; k < visible; k += 2) {
            double x = X[k] * c - Z[k] * s;
            double z = X[k] * s + Z[k] * c;
            double y = Y[k];
            vel(Particle.END_ROD,
                    cx + x * radius * 1.7, cy + y * radius * 1.7, cz + z * radius * 1.7,
                    -x, -y, -z, 0.12);
        }
        prevVisible = visible;
    }

    private void drawRing(int i, double r, double density) {
        double tilt = RING_TILT[i];
        double prec = tick * RING_PREC[i];
        double ct = Math.cos(tilt), st = Math.sin(tilt);
        double cp = Math.cos(prec), sp = Math.sin(prec);
        // базис плоскости кольца: наклон вокруг X, затем прецессия вокруг Y
        double ux = cp, uz = -sp;
        double vx = st * sp, vy = ct, vz = st * cp;
        double spin = tick * RING_SPIN[i];
        int limit = (int) (RING_POINTS * density);
        double step = 2.0 * Math.PI / RING_POINTS;

        for (int j = tick & 1; j < limit; j += 2) {
            double a = j * step + spin;
            double ca = Math.cos(a), sa = Math.sin(a);
            double x = cx + r * (ca * ux + sa * vx);
            double y = cy + r * (sa * vy);
            double z = cz + r * (ca * uz + sa * vz);
            int m = (j >> 1) % 8;
            if (m == 0) {
                burst(Particle.END_ROD, x, y, z, 1, 0, 0, 0, 0);
            } else if (m == 4) {
                burst(Particle.ELECTRIC_SPARK, x, y, z, 1, 0, 0, 0, 0);
            } else {
                dust((i & 1) == 0 ? GOLD_BRIGHT : GOLD, x, y, z, 1, 0, 0, 0);
            }
        }
    }

    // ---- Энергетические линии ----

    private void updateBeams() {
        if (tick >= 25 && tick < FLASH_TICK - 12 && tick % 5 == 0) {
            int add = 2 + rnd.nextInt(3);
            for (int i = 0; i < add && beams.size() < MAX_BEAMS; i++) {
                beams.add(newBeam());
            }
        }

        Iterator<Beam> it = beams.iterator();
        while (it.hasNext()) {
            Beam b = it.next();
            int age = tick - b.born;
            if (age >= b.life) {
                it.remove();
                continue;
            }
            double pr = age / (double) b.life;
            double grow = Math.min(1.0, pr / 0.35);
            double head = 0.8 + (b.length - 0.8) * (1.0 - (1.0 - grow) * (1.0 - grow));
            double tail = pr < 0.4 ? 0.8 : 0.8 + (b.length - 0.8) * ((pr - 0.4) / 0.6);

            int idx = 0;
            for (double d = tail; d <= head; d += 1.1, idx++) {
                double jx = (rnd.nextDouble() - 0.5) * 0.1;
                double jy = (rnd.nextDouble() - 0.5) * 0.1;
                double jz = (rnd.nextDouble() - 0.5) * 0.1;
                double x = cx + b.dx * d + jx;
                double y = cy + b.dy * d + jy;
                double z = cz + b.dz * d + jz;
                if ((idx & 1) == 0) {
                    burst(Particle.ELECTRIC_SPARK, x, y, z, 1, 0, 0, 0, 0);
                } else {
                    dust(GOLD_BRIGHT, x, y, z, 1, 0, 0, 0);
                }
            }
            double hx = cx + b.dx * head;
            double hy = cy + b.dy * head;
            double hz = cz + b.dz * head;
            burst(Particle.END_ROD, hx, hy, hz, 3, 0.1, 0.1, 0.1, 0.01);
            burst(Particle.GLOW, hx, hy, hz, 2, 0.15, 0.15, 0.15, 0.01);
        }
    }

    private Beam newBeam() {
        double gx = rnd.nextGaussian(), gy = rnd.nextGaussian(), gz = rnd.nextGaussian();
        double len = Math.sqrt(gx * gx + gy * gy + gz * gz);
        if (len < 1.0e-6) {
            gx = 1.0;
            gy = 0.0;
            gz = 0.0;
            len = 1.0;
        }
        gx /= len;
        gy /= len;
        gz /= len;
        if (gy < -0.6) {
            gy = -gy;
        }
        return new Beam(gx, gy, gz, 12.0 + rnd.nextDouble() * 14.0, tick, 24 + rnd.nextInt(20));
    }

    // ---- Потоки от земли ----

    private void drawGround() {
        if (tick < 8) {
            return;
        }
        double ramp = Math.min(1.0, (tick - 8) / 40.0);
        int cols = (int) (COLUMNS * ramp);
        double base = tick * 0.07;
        double colStep = 2.0 * Math.PI / COLUMNS;

        for (int c = 0; c < cols; c++) {
            double a = base + c * colStep;
            double ca = Math.cos(a), sa = Math.sin(a);
            double rad = 3.2 + 1.8 * Math.sin(tick * 0.05 + c);
            double x = ox + ca * rad;
            double z = oz + sa * rad;
            vel(Particle.END_ROD, x, oy + 0.15, z,
                    -ca * 0.03 - sa * 0.12, 1.0, -sa * 0.03 + ca * 0.12, 0.45 + 0.1 * (c % 3));
            if ((c & 1) == (tick & 1)) {
                vel(Particle.GLOW, x, oy + 0.15, z, 0.0, 1.0, 0.0, 0.3);
            }
            dust(GOLD, x, oy + 0.1, z, 2, 0.2, 0.0, 0.2);
        }

        // вращающийся магический круг на земле
        double rr = 6.5;
        for (int j = tick % 3; j < 36; j += 3) {
            double a = j * (2.0 * Math.PI / 36.0) - tick * 0.03;
            dust(GOLD_BRIGHT, ox + Math.cos(a) * rr, oy + 0.1, oz + Math.sin(a) * rr, 1, 0, 0, 0);
        }
    }

    // ---- Фон ----

    private void drawAmbient(double radius) {
        burst(Particle.WAX_ON, cx, cy, cz, 10, radius * 0.8, radius * 0.8, radius * 0.8, 0.0);
        burst(Particle.GLOW, cx, cy, cz, 6, radius * 1.3, radius * 1.3, radius * 1.3, 0.01);

        for (int n = 0; n < 8; n++) {
            double gx = rnd.nextGaussian(), gy = rnd.nextGaussian(), gz = rnd.nextGaussian();
            double len = Math.sqrt(gx * gx + gy * gy + gz * gz);
            if (len < 1.0e-6) {
                continue;
            }
            double k = radius / len;
            double px = cx + gx * k, py = cy + gy * k, pz = cz + gz * k;
            burst(Particle.ELECTRIC_SPARK, px, py, pz, 1, 0, 0, 0, 0);
            if ((n & 3) == 0) {
                burst(Particle.FIREWORK, px, py, pz, 2, 0, 0, 0, 0.03);
            }
        }
        if (tick % 4 == 0) {
            burst(Particle.TOTEM_OF_UNDYING, cx, cy, cz, 6, 0.4, 0.4, 0.4, 0.35);
        }
        if (tick % 3 == 0) {
            dust(GOLD, cx, cy, cz, 25, radius * 0.9, radius * 0.9, radius * 0.9);
        }
    }

    // =====================================================================
    // Вспышка и затухание
    // =====================================================================

    private void flash() {
        dust(WHITE_GOLD, cx, cy, cz, 220, 1.4, 1.4, 1.4);
        dust(CORE_GOLD, cx, cy, cz, 160, 2.2, 2.2, 2.2);
        burst(Particle.END_ROD, cx, cy, cz, 120, 0.5, 0.5, 0.5, 0.6);
        burst(Particle.GLOW, cx, cy, cz, 160, 2.5, 2.5, 2.5, 0.5);
        burst(Particle.TOTEM_OF_UNDYING, cx, cy, cz, 120, 0.3, 0.3, 0.3, 1.0);

        for (int i = 0; i < SphereData.DIR_COUNT; i++) {
            double dx = SphereData.DX[i], dy = SphereData.DY[i], dz = SphereData.DZ[i];
            double sp = 0.9 + 0.5 * (i % 4);
            vel(Particle.END_ROD, cx, cy, cz, dx, dy, dz, sp);
            if (i % 2 == 0) {
                vel(Particle.FIREWORK, cx, cy, cz, dx, dy, dz, sp * 0.8);
            }
            if (i % 3 == 0) {
                vel(Particle.ELECTRIC_SPARK, cx, cy, cz, dx, dy, dz, sp * 1.3);
            }
            if (i % 5 == 0) {
                vel(Particle.TOTEM_OF_UNDYING, cx, cy, cz, dx, dy, dz, sp * 0.9);
            }
            if (i % 7 == 0) {
                vel(Particle.WAX_ON, cx, cy, cz, dx, dy, dz, sp * 0.6);
            }
        }
    }

    private void afterFlash(int t) {
        double fade = 1.0 - t / (double) (TOTAL_TICKS - FLASH_TICK);
        if (fade <= 0.0) {
            return;
        }
        double f2 = fade * fade;

        // кольца разлетаются и тают
        for (int i = 0; i < RING_R.length; i++) {
            drawRing(i, RING_R[i] + t * 0.9, fade);
        }

        // расширяющиеся золотые оболочки
        double r1 = RADIUS + t * 0.55;
        int n1 = (int) (450 * f2);
        for (int k = 0; k < n1; k++) {
            int idx = (k * 7 + tick * 13) % SphereData.COUNT;
            double px = cx + SphereData.X[idx] * r1;
            double py = cy + SphereData.Y[idx] * r1;
            double pz = cz + SphereData.Z[idx] * r1;
            dust((k & 1) == 0 ? GOLD_BRIGHT : GOLD, px, py, pz, 1, 0, 0, 0);
        }
        double r2 = RADIUS * 0.6 + t * 0.32;
        int n2 = (int) (220 * fade);
        for (int k = 0; k < n2; k++) {
            int idx = (k * 11 + tick * 5) % SphereData.COUNT;
            burst(Particle.ELECTRIC_SPARK,
                    cx + SphereData.X[idx] * r2, cy + SphereData.Y[idx] * r2, cz + SphereData.Z[idx] * r2,
                    1, 0, 0, 0, 0);
        }

        // остаточное свечение ядра
        if (t < 30) {
            double k = 1.0 - t / 30.0;
            dust(WHITE_GOLD, cx, cy, cz, (int) (20 * k), 1.0, 1.0, 1.0);
            burst(Particle.END_ROD, cx, cy, cz, (int) (12 * k), 0.8, 0.8, 0.8, 0.05);
        }

        // золотая «пыль» и мерцание
        burst(Particle.GLOW, cx, cy, cz, (int) (30 * fade), r1 * 0.5, r1 * 0.35, r1 * 0.5, 0.01);
        burst(Particle.WAX_ON, cx, cy, cz, (int) (20 * fade), r1 * 0.4, r1 * 0.3, r1 * 0.4, 0.0);
        int falling = (int) (25 * fade);
        if (falling > 0) {
            world.spawnParticle(Particle.FALLING_DUST, cx, cy - 2.0, cz, falling, 12.0, 5.0, 12.0, 0.0, GOLD_BLOCK, true);
        }
    }

    // =====================================================================
    // Помощники отправки частиц (force = true → видно на большой дистанции)
    // =====================================================================

    private void burst(Particle particle, double x, double y, double z, int count,
                       double ox, double oy, double oz, double speed) {
        if (count <= 0) {
            return;
        }
        world.spawnParticle(particle, x, y, z, count, ox, oy, oz, speed, null, true);
    }

    /** count = 0: (dx,dy,dz) × speed — это вектор скорости частицы. */
    private void vel(Particle particle, double x, double y, double z,
                     double dx, double dy, double dz, double speed) {
        world.spawnParticle(particle, x, y, z, 0, dx, dy, dz, speed, null, true);
    }

    private void dust(Particle.DustOptions options, double x, double y, double z, int count,
                      double ox, double oy, double oz) {
        if (count <= 0) {
            return;
        }
        world.spawnParticle(Particle.DUST, x, y, z, count, ox, oy, oz, 0.0, options, true);
    }
}

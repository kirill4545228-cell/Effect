package dev.goldencelestial;

import java.util.Random;

/** Предрассчитанные направления (спираль Фибоначчи), чтобы не считать их каждый тик. */
final class SphereData {

    static final int COUNT = 1500;
    static final int DIR_COUNT = 480;

    /** Точки на единичной сфере в случайном (но фиксированном) порядке. */
    static final double[] X = new double[COUNT];
    static final double[] Y = new double[COUNT];
    static final double[] Z = new double[COUNT];

    /** Равномерные направления для финальной вспышки. */
    static final double[] DX = new double[DIR_COUNT];
    static final double[] DY = new double[DIR_COUNT];
    static final double[] DZ = new double[DIR_COUNT];

    static {
        fibonacci(X, Y, Z, COUNT);
        Random random = new Random(1337L);
        for (int i = COUNT - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            double t = X[i]; X[i] = X[j]; X[j] = t;
            t = Y[i]; Y[i] = Y[j]; Y[j] = t;
            t = Z[i]; Z[i] = Z[j]; Z[j] = t;
        }
        fibonacci(DX, DY, DZ, DIR_COUNT);
    }

    private SphereData() {
    }

    private static void fibonacci(double[] xs, double[] ys, double[] zs, int n) {
        double golden = Math.PI * (3.0 - Math.sqrt(5.0));
        for (int i = 0; i < n; i++) {
            double y = 1.0 - 2.0 * (i + 0.5) / n;
            double r = Math.sqrt(1.0 - y * y);
            double theta = golden * i;
            xs[i] = Math.cos(theta) * r;
            ys[i] = y;
            zs[i] = Math.sin(theta) * r;
        }
    }
}

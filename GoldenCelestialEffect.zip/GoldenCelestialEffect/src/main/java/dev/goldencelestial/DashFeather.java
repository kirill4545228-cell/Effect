package dev.goldencelestial;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Одноразовое перо: ПКМ — игрока именно толкает вперёд (через скорость, не телепорт)
 * примерно на 5 блоков. Перо расходуется при использовании.
 */
public final class DashFeather implements Listener {

    /** Рывок = DASH_TICKS тиков со скоростью DASH_SPEED блоков/тик → ~5 блоков. */
    private static final int DASH_TICKS = 6;
    private static final double DASH_SPEED = 0.8;

    private static final Particle.DustOptions GOLD = new Particle.DustOptions(Color.fromRGB(255, 205, 40), 1.4f);

    private final GoldenCelestialEffect plugin;
    private final NamespacedKey key;
    private final Map<UUID, BukkitRunnable> dashes = new HashMap<>();

    public DashFeather(GoldenCelestialEffect plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "dash_feather");
    }

    public ItemStack createFeather() {
        ItemStack item = new ItemStack(Material.FEATHER);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Золотое перо рывка", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("ПКМ — рывок вперёд на 5 блоков", NamedTextColor.YELLOW)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Одноразовое", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isFeather(ItemStack item) {
        if (item == null || item.getType() != Material.FEATHER || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (!isFeather(hand)) {
            return;
        }
        event.setCancelled(true);
        if (dashes.containsKey(player.getUniqueId())) {
            return;
        }

        // расходуем одно перо
        if (hand.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        } else {
            hand.setAmount(hand.getAmount() - 1);
            player.getInventory().setItemInMainHand(hand);
        }
        startDash(player);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        BukkitRunnable task = dashes.remove(event.getPlayer().getUniqueId());
        if (task != null) {
            task.cancel();
        }
    }

    private void startDash(Player player) {
        double yaw = Math.toRadians(player.getLocation().getYaw());
        final double dirX = -Math.sin(yaw);
        final double dirZ = Math.cos(yaw);
        final UUID id = player.getUniqueId();

        Location start = player.getLocation();
        start.getWorld().playSound(start, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.6f);
        start.getWorld().playSound(start, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.8f);
        start.getWorld().spawnParticle(Particle.FIREWORK, start.getX(), start.getY() + 0.5, start.getZ(),
                14, 0.2, 0.3, 0.2, 0.12, null, true);

        BukkitRunnable task = new BukkitRunnable() {
            private int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead()) {
                    finish();
                    return;
                }
                Vector current = player.getVelocity();
                if (ticks >= DASH_TICKS) {
                    // гасим инерцию скольжения, вертикаль не трогаем
                    player.setVelocity(new Vector(0.0, current.getY(), 0.0));
                    finish();
                    return;
                }
                double y = player.isOnGround() ? 0.0 : Math.max(-0.4, Math.min(0.42, current.getY()));
                player.setVelocity(new Vector(dirX * DASH_SPEED, y, dirZ * DASH_SPEED));

                Location l = player.getLocation();
                double x = l.getX(), py = l.getY() + 0.9, z = l.getZ();
                player.getWorld().spawnParticle(Particle.END_ROD, x, py, z, 6, 0.25, 0.4, 0.25, 0.02, null, true);
                player.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, x, py, z, 8, 0.3, 0.4, 0.3, 0.05, null, true);
                player.getWorld().spawnParticle(Particle.DUST, x, py, z, 10, 0.3, 0.45, 0.3, 0.0, GOLD, true);
                ticks++;
            }

            private void finish() {
                dashes.remove(id);
                cancel();
            }
        };
        dashes.put(id, task);
        task.runTaskTimer(plugin, 0L, 1L);
    }

    public void shutdown() {
        for (BukkitRunnable task : new java.util.ArrayList<>(dashes.values())) {
            task.cancel();
        }
        dashes.clear();
    }
}
